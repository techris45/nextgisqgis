# -*- coding: utf-8 -*-

"""
***************************************************************************
    doProximity.py
    ---------------------
    Date                 : June 2010
    Copyright            : (C) 2010 by Giuseppe Sucameli
    Email                : brush dot tyler at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Giuseppe Sucameli'
__date__ = 'June 2010'
__copyright__ = '(C) 2010, Giuseppe Sucameli'
# This will get replaced with a git SHA1 when you do a git archive
__revision__ = '$Format:%H$'

from qgis.PyQt.QtWidgets import QWidget

from .ui_widgetProximity import Ui_GdalToolsWidget as Ui_Widget
from .widgetPluginBase import GdalToolsBasePluginWidget as BasePluginWidget
from . import GdalTools_utils as Utils


class GdalToolsDialog(QWidget, Ui_Widget, BasePluginWidget):

    def __init__(self, iface):
        QWidget.__init__(self)
        self.iface = iface

        self.setupUi(self)
        BasePluginWidget.__init__(self, self.iface, "gdal_proximity.py")

        self.outSelector.setType(self.outSelector.FILE)
        self.outputFormat = Utils.fillRasterOutputFormat()

        self.setParamsStatus([
            (self.inSelector, "filenameChanged"),
            (self.outSelector, "filenameChanged"),
            (self.valuesEdit, "textChanged", self.valuesCheck),
            (self.distUnitsCombo, "currentIndexChanged", self.distUnitsCheck),
            (self.maxDistSpin, "valueChanged", self.maxDistCheck),
            (self.noDataSpin, "valueChanged", self.noDataCheck),
            (self.fixedBufValSpin, "valueChanged", self.fixedBufValCheck)
        ])

        self.inSelector.selectClicked.connect(self.fillInputFileEdit)
        self.outSelector.selectClicked.connect(self.fillOutputFileEdit)

    def onLayersChanged(self):
        self.inSelector.setLayers(Utils.LayerRegistry().getRasterLayers())

    def fillInputFileEdit(self):
        lastUsedFilter = Utils.FileFilter.lastUsedRasterFilter()
        inputFile = Utils.FileDialog.getOpenFileName(self, self.tr("Select the input file for Proximity"), Utils.FileFilter.allRastersFilter(), lastUsedFilter)
        if not inputFile:
            return
        Utils.FileFilter.setLastUsedRasterFilter(lastUsedFilter)

        self.inSelector.setFilename(inputFile)

    def fillOutputFileEdit(self):
        lastUsedFilter = Utils.FileFilter.lastUsedRasterFilter()
        outputFile = Utils.FileDialog.getSaveFileName(self, self.tr("Select the raster file to save the results to"), Utils.FileFilter.saveRastersFilter(), lastUsedFilter)
        if not outputFile:
            return
        Utils.FileFilter.setLastUsedRasterFilter(lastUsedFilter)

        self.outputFormat = Utils.fillRasterOutputFormat(lastUsedFilter, outputFile)
        self.outSelector.setFilename(outputFile)

    def getArguments(self):
        arguments = []
        arguments.append(self.getInputFileName())
        outputFn = self.getOutputFileName()
        arguments.append(outputFn)
        if self.valuesCheck.isChecked():
            values = self.valuesEdit.text().split()
            if values:
                arguments.append("-values")
                arguments.append(','.join(values))
        if self.distUnitsCheck.isChecked() and self.distUnitsCombo.currentIndex() >= 0:
            arguments.append("-distunits")
            arguments.append(self.distUnitsCombo.currentText())
        if self.maxDistCheck.isChecked():
            arguments.append("-maxdist")
            arguments.append(unicode(self.maxDistSpin.value()))
        if self.noDataCheck.isChecked():
            arguments.append("-nodata")
            arguments.append(unicode(self.noDataSpin.value()))
        if self.fixedBufValCheck.isChecked():
            arguments.append("-fixed-buf-val")
            arguments.append(unicode(self.fixedBufValSpin.value()))
        if outputFn:
            arguments.append("-of")
            arguments.append(self.outputFormat)
        return arguments

    def getOutputFileName(self):
        return self.outSelector.filename()

    def getInputFileName(self):
        return self.inSelector.filename()

    def addLayerIntoCanvas(self, fileInfo):
        self.iface.addRasterLayer(fileInfo.filePath())
